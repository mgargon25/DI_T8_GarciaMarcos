/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package masgrande;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author marco
 */
public class MasGrandeTest {
    
    public MasGrandeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of max method, of class MasGrande.
     */
    @Test
    public void testMaxCardValorUnico() {
        System.out.println("Comprueba que el numero es 1 cuando el array solo tiene el valor 1");
        int[] a = {1};
        int expResult = 1;
        int result = MasGrande.max(a);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testMaxCardValores() {
        System.out.println("Comprueba que el numero mayor es 3 cuando el array está compuesto de [1,2,3]");
        int[] a = {1,2,3};
        int expResult = 3;
        int result = MasGrande.max(a);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testMaxCardValoresOrd() {
        System.out.println("Comprueba que el numero 7 es el mayor cuando el array está compuesto de [5,7,2]");
        int[] a = {5,7,3,2};
        int expResult = 7;
        int result = MasGrande.max(a);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testMaxCardSinValores() {
        System.out.println("Comprueba que el numero es el mayor cuando el array está compuesto de [5,7,2]");
        int[] a = {};
        int expResult = 0;
        int result = MasGrande.max(a);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testMaxCardValorNeg() {
        System.out.println("Comprueba que el numero es el mayor cuando el array está compuesto de [5,7,2]");
        int[] a = {5,-6,3};
        int expResult = 5;
        int result = MasGrande.max(a);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testMaxCardValoresNeg() {
        System.out.println("Comprueba que el numero es el mayor cuando el array está compuesto de [5,7,2]");
        int[] a = {-1,-5,-6};
        int expResult = -1;
        int result = MasGrande.max(a);
        assertEquals(expResult, result);
    }
    
    
    @Test
    public void testExistenciaMax() {
        System.out.println("max");
        int[] a = null;
        int expResult = -1;
        int result = MasGrande.max(a);
        assertEquals(expResult, result);
    }
    
    
    
}
